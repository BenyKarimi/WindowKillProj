package controller.constant;

public class KeyActions {
    public static int UP = 38;
    public static int DOWN = 40;
    public static int LEFT = 37;
    public static int RIGHT = 39;
    public static int showStore = 10;
    public static int skillTreeAttack = 49;
    public static int skillTreeDefence = 50;
    public static int skillTreeProteus = 51;
}
