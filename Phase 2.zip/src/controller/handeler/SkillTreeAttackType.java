package controller.handeler;

public enum SkillTreeAttackType {
    ARES, ASTRAPE, CERBERUS
}
