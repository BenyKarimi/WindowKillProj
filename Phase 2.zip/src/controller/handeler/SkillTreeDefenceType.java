package controller.handeler;

public enum SkillTreeDefenceType {
    ACESO, MELAMPUS, CHIRON
}
