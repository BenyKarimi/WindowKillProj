package controller.handeler;

public enum SkillTreeTransformationType {
    PROTEUS, EMPUSA, DOLUS
}
