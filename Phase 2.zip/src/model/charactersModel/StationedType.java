package model.charactersModel;
public enum StationedType {
    HIDE, PRE_SHOW, SHOW
}
