package model.charactersModel.boss;

public enum BossAttackType {
    SQUEEZE, PROJECTILE, VOMIT, POWER_PUNCH, QUAKE, RAPID_FIRE, SLAP
}
