package model.panelModel;

public enum Isometric {
    YES, NO
}
