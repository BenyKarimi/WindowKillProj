package model.panelModel;

public enum Rigid {
    YES, NO
}
