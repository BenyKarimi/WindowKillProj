package model.panelModel;

public enum WallSideIndicator {
    LEFT, RIGHT, UP, DOWN
}
