package controller.constant;

public enum Level {
    EASY, MEDIUM, HARD
}
